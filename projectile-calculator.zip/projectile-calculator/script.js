document.addEventListener('DOMContentLoaded', () => {
    // --- DOM Elements ---
    const form = document.getElementById('projectileForm');
    const outputDiv = document.getElementById('output');
    const resultsSection = document.getElementById('results');
    const trajectoryChartCanvas = document.getElementById('trajectoryChart');
    const velocityChartCanvas = document.getElementById('velocityChart');
    const airResistanceCheckbox = document.getElementById('airResistance');
    const airResistanceFields = document.getElementById('airResistanceFields');
    const downloadCSVBtn = document.getElementById('downloadCSV');
    const downloadPNGBtn = document.getElementById('downloadPNG');

    // --- Show/Hide Air Resistance Fields ---
    airResistanceCheckbox.addEventListener('change', () => {
        airResistanceFields.style.display = airResistanceCheckbox.checked ? 'block' : 'none';
    });

    // --- Chart.js Chart Holders ---
    let trajectoryChart = null;
    let velocityChart = null;

    // --- Utility Functions ---
    function toRadians(degrees) {
        return degrees * Math.PI / 180;
    }
    function round2(x) {
        return Math.round(x * 100) / 100;
    }

    // --- Main Calculation ---
    form.addEventListener('submit', (e) => {
        e.preventDefault();

        // --- Get Inputs ---
        const v0 = parseFloat(document.getElementById('velocity').value);
        const angleDeg = parseFloat(document.getElementById('angle').value);
        const h0 = parseFloat(document.getElementById('height').value);
        const g = parseFloat(document.getElementById('gravity').value);
        const wind = parseFloat(document.getElementById('wind').value);
        const useAirResistance = airResistanceCheckbox.checked;

        // Air resistance params
        let Cd = 0, A = 0, m = 0, rho = 0;
        if (useAirResistance) {
            Cd = parseFloat(document.getElementById('dragCoeff').value);
            A = parseFloat(document.getElementById('area').value);
            m = parseFloat(document.getElementById('mass').value);
            rho = parseFloat(document.getElementById('airDensity').value);
        }

        // --- Initial Calculations ---
        const angleRad = toRadians(angleDeg);
        let v0x = v0 * Math.cos(angleRad) + wind;
        let v0y = v0 * Math.sin(angleRad);

        // --- Arrays for Table/Graph ---
        let data = [];
        let t = 0, dt = 0.02;
        let x = 0, y = h0;
        let vx = v0x, vy = v0y;

        // --- Air Resistance or Not ---
        if (!useAirResistance) {
            // Analytical solution (no air resistance)
            const discriminant = v0y * v0y + 2 * g * h0;
            const t_flight = (v0y + Math.sqrt(discriminant)) / g;
            const t_total = 2 * v0y / g + Math.sqrt(discriminant) / g;
            const totalTime = Math.max(t_flight, t_total);

            for (t = 0; t <= totalTime + 0.01; t += dt) {
                x = v0x * t;
                y = h0 + v0y * t - 0.5 * g * t * t;
                vx = v0x;
                vy = v0y - g * t;
                data.push({ t: round2(t), x: round2(x), y: round2(y), vx: round2(vx), vy: round2(vy) });
                if (y < 0) break;
            }

            const maxHeight = h0 + (v0y * v0y) / (2 * g);
            const range = v0x * data[data.length - 1].t;
            const finalVx = v0x;
            const finalVy = v0y - g * data[data.length - 1].t;
            const finalV = Math.sqrt(finalVx * finalVx + finalVy * finalVy);
            const finalAngle = Math.atan2(finalVy, finalVx) * 180 / Math.PI;

            outputDiv.innerHTML = `
                <b>Time of Flight:</b> ${round2(data[data.length - 1].t)} s<br>
                <b>Maximum Height:</b> ${round2(maxHeight)} m<br>
                <b>Range:</b> ${round2(range)} m<br>
                <b>Final Velocity:</b> ${round2(finalV)} m/s at ${round2(finalAngle)}°<br>
                <b>Trajectory Equation:</b> y(x) = ${h0} + tan(${angleDeg})·x - (${g}·x²)/(2·${v0x*v0x})<br>
            `;

        } else {
            // Numerical solution (Euler method for air resistance)
            for (t = 0; t < 100; t += dt) {
                const v = Math.sqrt(vx * vx + vy * vy);
                const Fd = 0.5 * Cd * A * rho * v * v;
                const Fdx = Fd * (vx / v);
                const Fdy = Fd * (vy / v);
                const ax = -Fdx / m;
                const ay = -g - Fdy / m;
                vx += ax * dt;
                vy += ay * dt;
                x += vx * dt;
                y += vy * dt;
                data.push({ t: round2(t), x: round2(x), y: round2(y), vx: round2(vx), vy: round2(vy) });
                if (y < 0) break;
            }
            const maxHeight = Math.max(...data.map(pt => pt.y));
            const range = data[data.length - 1].x;
            const finalVx = data[data.length - 1].vx;
            const finalVy = data[data.length - 1].vy;
            const finalV = Math.sqrt(finalVx * finalVx + finalVy * finalVy);
            const finalAngle = Math.atan2(finalVy, finalVx) * 180 / Math.PI;

            outputDiv.innerHTML = `
                <b>Time of Flight:</b> ${round2(data[data.length - 1].t)} s<br>
                <b>Maximum Height:</b> ${round2(maxHeight)} m<br>
                <b>Range:</b> ${round2(range)} m<br>
                <b>Final Velocity:</b> ${round2(finalV)} m/s at ${round2(finalAngle)}°<br>
                <b>Trajectory Equation:</b> <i>Numerical solution with air resistance</i><br>
            `;
        }

        resultsSection.style.display = 'block';

        // --- Plot Trajectory ---
        if (trajectoryChart) trajectoryChart.destroy();
        trajectoryChart = new Chart(trajectoryChartCanvas, {
            type: 'line',
            data: {
                labels: data.map(pt => pt.x),
                datasets: [{
                    label: 'Trajectory (y vs x)',
                    data: data.map(pt => pt.y),
                    borderColor: '#00d8ff',
                    backgroundColor: 'rgba(0,216,255,0.08)',
                    pointRadius: 0,
                    tension: 0.05
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false }},
                scales: {
                    x: { title: { display: true, text: 'Horizontal Distance (m)' }, ticks: { color: '#f1f1f1' } },
                    y: { title: { display: true, text: 'Height (m)' }, beginAtZero: true, ticks: { color: '#f1f1f1' } }
                }
            }
        });

        // --- Plot Velocity vs Time ---
        if (velocityChart) velocityChart.destroy();
        velocityChart = new Chart(velocityChartCanvas, {
            type: 'line',
            data: {
                labels: data.map(pt => pt.t),
                datasets: [
                    {
                        label: 'Vx (m/s)',
                        data: data.map(pt => pt.vx),
                        borderColor: '#39ff14',
                        backgroundColor: 'rgba(57,255,20,0.08)',
                        pointRadius: 0,
                        tension: 0.05
                    },
                    {
                        label: 'Vy (m/s)',
                        data: data.map(pt => pt.vy),
                        borderColor: '#e040fb',
                        backgroundColor: 'rgba(224,64,251,0.08)',
                        pointRadius: 0,
                        tension: 0.05
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: true }},
                scales: {
                    x: { title: { display: true, text: 'Time (s)' }, ticks: { color: '#f1f1f1' } },
                    y: { title: { display: true, text: 'Velocity (m/s)' }, ticks: { color: '#f1f1f1' } }
                }
            }
        });

        // --- Download CSV ---
        downloadCSVBtn.onclick = () => {
            let csv = "t(s),x(m),y(m),vx(m/s),vy(m/s)\n";
            data.forEach(pt => {
                csv += `${pt.t},${pt.x},${pt.y},${pt.vx},${pt.vy}\n`;
            });
            const blob = new Blob([csv], { type: "text/csv" });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = "projectile_data.csv";
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        };

        // --- Download Trajectory Chart as PNG ---
        downloadPNGBtn.onclick = () => {
            const link = document.createElement('a');
            link.href = trajectoryChartCanvas.toDataURL('image/png');
            link.download = 'trajectory_chart.png';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        };
    });
});
